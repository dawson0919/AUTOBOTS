/**
 * risk/manager.js
 * 風控模組 — 每筆訂單進場前強制過濾
 *
 * 功能：
 *  - 每筆最大虧損限制
 *  - 每日最大虧損熔斷
 *  - 最大同時持倉數
 *  - 保證金使用率上限
 *  - 計算建議倉位大小（Kelly / Fixed Fraction）
 */

const logger = require('../utils/logger');
const EventEmitter = require('events');

class RiskManager extends EventEmitter {
  constructor(config = {}) {
    super();
    this.config = {
      maxRiskPerTrade:  config.maxRiskPerTrade  ?? 0.02,   // 每筆最大虧損 2%
      maxDailyLoss:     config.maxDailyLoss     ?? 0.05,   // 每日熔斷 5%
      maxOpenPositions: config.maxOpenPositions ?? 5,       // 最多同時持倉
      maxMarginUsage:   config.maxMarginUsage   ?? 0.60,   // 保證金使用上限 60%
      minSignalStrength:config.minSignalStrength?? 3,       // 最低信號強度（1~3）
      tradeOnWeakSignal:config.tradeOnWeakSignal?? false,   // 是否交易弱信號
    };

    this.state = {
      dailyStartBalance: 0,
      dailyPnl:          0,
      openPositions:     new Map(),   // symbol => position object
      totalTrades:       0,
      wins:              0,
      losses:            0,
      halted:            false,       // 熔斷狀態
      haltReason:        '',
    };

    // 每天 00:00 重置每日統計
    this._scheduleDailyReset();
  }

  // ─────────────────────────────────────────
  //  初始化（傳入帳戶餘額）
  // ─────────────────────────────────────────
  init(balance) {
    this.state.dailyStartBalance = balance;
    logger.info(`[Risk] 初始化完成，帳戶餘額: $${balance.toFixed(2)}`);
  }

  // ─────────────────────────────────────────
  //  進場前檢查 — 回傳 { allowed, reason }
  // ─────────────────────────────────────────
  checkEntry({ symbol, signal, balance }) {
    const { state, config } = this;

    // 1. 熔斷檢查
    if (state.halted) {
      return { allowed: false, reason: `熔斷中: ${state.haltReason}` };
    }

    // 2. 每日虧損上限
    const dailyLossPct = state.dailyPnl / state.dailyStartBalance;
    if (dailyLossPct < -config.maxDailyLoss) {
      this._halt(`每日虧損 ${(dailyLossPct * 100).toFixed(2)}% 超過上限`);
      return { allowed: false, reason: state.haltReason };
    }

    // 3. 最大持倉數
    if (state.openPositions.size >= config.maxOpenPositions) {
      return {
        allowed: false,
        reason: `持倉已達上限 (${state.openPositions.size}/${config.maxOpenPositions})`,
      };
    }

    // 4. 已有同一交易對持倉
    if (state.openPositions.has(symbol)) {
      return { allowed: false, reason: `${symbol} 已有未平倉部位` };
    }

    // 5. 信號強度
    if (!config.tradeOnWeakSignal && signal.strength < config.minSignalStrength) {
      return {
        allowed: false,
        reason: `信號強度不足 (${signal.strength}/${config.minSignalStrength})`,
      };
    }

    // 6. 保證金使用率
    const marginUsed = this._calcMarginUsage(balance);
    if (marginUsed >= config.maxMarginUsage) {
      return {
        allowed: false,
        reason: `保證金使用率過高 (${(marginUsed * 100).toFixed(1)}%)`,
      };
    }

    return { allowed: true, reason: 'OK' };
  }

  // ─────────────────────────────────────────
  //  計算倉位大小（Fixed Fraction）
  //  position = balance * riskPct / stopLossPct
  // ─────────────────────────────────────────
  calcPositionSize({ balance, entryPrice, stopLossPrice }) {
    const riskAmount  = balance * this.config.maxRiskPerTrade;
    const slDistance  = Math.abs(entryPrice - stopLossPrice);
    const slPct       = slDistance / entryPrice;

    if (slPct === 0) return 0;

    const usdtToUse   = riskAmount / slPct;
    const qty         = usdtToUse / entryPrice;

    return {
      qty:        +qty.toFixed(6),
      usdtValue:  +usdtToUse.toFixed(2),
      riskAmount: +riskAmount.toFixed(2),
      slPct:      +(slPct * 100).toFixed(2),
    };
  }

  // ─────────────────────────────────────────
  //  開倉記錄
  // ─────────────────────────────────────────
  recordOpen({ symbol, side, entryPrice, qty, stopLoss, takeProfit, orderId }) {
    this.state.openPositions.set(symbol, {
      symbol, side, entryPrice, qty, stopLoss, takeProfit, orderId,
      openTime: Date.now(),
    });
    this.state.totalTrades++;
    logger.info(`[Risk] 開倉記錄: ${side} ${symbol} x${qty} @ ${entryPrice}`);
  }

  // ─────────────────────────────────────────
  //  平倉記錄
  // ─────────────────────────────────────────
  recordClose({ symbol, exitPrice, pnl }) {
    const pos = this.state.openPositions.get(symbol);
    if (!pos) return;

    this.state.openPositions.delete(symbol);
    this.state.dailyPnl += pnl;

    if (pnl > 0) this.state.wins++;
    else         this.state.losses++;

    logger.info(`[Risk] 平倉: ${symbol} PNL=${pnl > 0 ? '+' : ''}${pnl.toFixed(2)}`);
    this.emit('position:closed', { symbol, pnl, exitPrice });
  }

  // ─────────────────────────────────────────
  //  即時檢查止損止盈
  // ─────────────────────────────────────────
  checkPositions(currentPrices) {
    const triggered = [];

    for (const [symbol, pos] of this.state.openPositions) {
      const price = currentPrices[symbol];
      if (!price) continue;

      const isLong = pos.side === 'BUY';

      const slHit = isLong ? price <= pos.stopLoss  : price >= pos.stopLoss;
      const tpHit = isLong ? price >= pos.takeProfit : price <= pos.takeProfit;

      if (slHit) triggered.push({ symbol, reason: 'SL', price, pos });
      else if (tpHit) triggered.push({ symbol, reason: 'TP', price, pos });
    }

    return triggered;
  }

  // ─────────────────────────────────────────
  //  統計 & 狀態
  // ─────────────────────────────────────────
  getStats() {
    const { state } = this;
    const total = state.wins + state.losses;
    return {
      totalTrades:   state.totalTrades,
      wins:          state.wins,
      losses:        state.losses,
      winRate:       total > 0 ? +(state.wins / total * 100).toFixed(1) : 0,
      dailyPnl:      +state.dailyPnl.toFixed(2),
      openPositions: state.openPositions.size,
      halted:        state.halted,
      haltReason:    state.haltReason,
    };
  }

  getOpenPositions() {
    return Array.from(this.state.openPositions.values());
  }

  // ─────────────────────────────────────────
  //  熔斷 / 重置
  // ─────────────────────────────────────────
  _halt(reason) {
    this.state.halted     = true;
    this.state.haltReason = reason;
    logger.error(`[Risk] ⚠️  熔斷觸發: ${reason}`);
    this.emit('halt', reason);
  }

  resetHalt() {
    this.state.halted     = false;
    this.state.haltReason = '';
    logger.info('[Risk] 熔斷已手動重置');
  }

  _calcMarginUsage(currentBalance) {
    const usedMargin = Array.from(this.state.openPositions.values())
      .reduce((sum, p) => sum + p.qty * p.entryPrice, 0);
    return usedMargin / currentBalance;
  }

  _scheduleDailyReset() {
    const now  = new Date();
    const next = new Date(now);
    next.setUTCHours(0, 0, 0, 0);
    next.setUTCDate(next.getUTCDate() + 1);
    const delay = next - now;

    setTimeout(() => {
      logger.info('[Risk] 每日統計重置');
      this.state.dailyPnl = 0;
      if (this.state.halted && this.state.haltReason.includes('每日虧損')) {
        this.resetHalt();
      }
      this._scheduleDailyReset();
    }, delay);
  }
}

module.exports = RiskManager;
