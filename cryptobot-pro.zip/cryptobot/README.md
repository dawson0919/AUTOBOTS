# CryptoBot Pro — 派網自動交易機器人

## 目錄結構

```
cryptobot/
├── bot.js                  ← 主程序入口
├── package.json
├── exchange/
│   └── pionex.js           ← Pionex REST + WebSocket 封裝
├── strategy/
│   └── threeBlade.js       ← 三刀流策略（RSI + EMA + MACD）
├── risk/
│   └── manager.js          ← 風控模組
├── utils/
│   ├── logger.js           ← 日誌
│   ├── indicators.js       ← ATR 等指標工具
│   └── store.js            ← 交易記錄存儲
├── dashboard/
│   └── index.html          ← 交易儀表板
└── logs/
    ├── bot.log             ← 系統日誌（自動產生）
    └── trades.json         ← 交易歷史（自動產生）
```

---

## 快速開始

### 1. 安裝依賴

```bash
npm install
```

### 2. 設定 API Key

在 Pionex 後台取得 API Key / Secret Key，然後：

**方法 A — 環境變數（推薦）**
```bash
export PIONEX_API_KEY=你的ApiKey
export PIONEX_SECRET_KEY=你的SecretKey
```

**方法 B — 直接修改 bot.js**
```js
const CONFIG = {
  apiKey:    'pk_live_xxxxxxxx',
  secretKey: 'sk_live_xxxxxxxx',
  ...
}
```

### 3. 模擬交易啟動（DRY RUN）

```bash
npm start
```

控制台會顯示：
```
[INFO ] CryptoBot Pro 啟動
[INFO ] 模式: 📋 模擬交易 (DRY RUN)
[INFO ] Dashboard 儀表板啟動: http://localhost:3000
```

### 4. 開啟儀表板

瀏覽器打開 http://localhost:3000

### 5. 切換實盤

在 `bot.js` 中修改：
```js
dryRun: false,   // ← 改為 false
```

---

## 策略說明：三刀流

三個技術指標同時確認才入場：

| 刀 | 指標 | 做多條件 | 做空條件 |
|----|------|---------|---------|
| 第一刀 | RSI(14) | < 35 且反彈 | > 65 且回落 |
| 第二刀 | EMA 9/21 | 黃金交叉 ↑ | 死亡交叉 ↓ |
| 第三刀 | MACD Histogram | 由負轉正 | 由正轉負 |

三刀全中 = STRONG 信號 → 入場
兩刀吻合 = WEAK 信號 → 預設不入場

---

## 風控規則

| 規則 | 預設值 |
|------|--------|
| 每筆最大虧損 | 2% |
| 每日最大虧損熔斷 | 5% |
| 最大同時持倉 | 5 個 |
| 保證金使用上限 | 60% |
| 止盈倍數 (ATR) | 2.5x |
| 止損倍數 (ATR) | 1.5x |

---

## Dashboard API 端點

| 路由 | 說明 |
|------|------|
| GET / | 交易儀表板 HTML |
| GET /api/stats | KPI 總覽（餘額、PNL、勝率等） |
| GET /api/positions | 當前開倉部位 |
| GET /api/trades | 歷史交易記錄 |
| GET /api/health | 機器人健康狀態 |

---

## 擴展方向

- [ ] 回測模組（`backtest/run.js`）
- [ ] Telegram Bot 推播止盈/止損通知
- [ ] 多策略並行（網格、DCA）
- [ ] SQLite / MongoDB 持久化
- [ ] PM2 守護進程部署
- [ ] Docker 容器化

---

## PM2 部署（生產環境）

```bash
npm install -g pm2
pm2 start bot.js --name cryptobot
pm2 logs cryptobot
pm2 monit
```
