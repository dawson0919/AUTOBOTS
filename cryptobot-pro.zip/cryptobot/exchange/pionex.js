/**
 * exchange/pionex.js
 * Pionex（派網）REST + WebSocket 封裝
 * 支援：查帳戶、下單、查倉位、查K線
 */

const crypto  = require('crypto');
const axios   = require('axios');
const WebSocket = require('ws');
const EventEmitter = require('events');
const logger  = require('../utils/logger');

const BASE_URL = 'https://api.pionex.com';
const WS_URL   = 'wss://ws.pionex.com/wsPub';

class PionexClient extends EventEmitter {
  constructor({ apiKey, secretKey }) {
    super();
    this.apiKey    = apiKey;
    this.secretKey = secretKey;
    this.ws        = null;
    this.wsReady   = false;
    this.pingTimer = null;
    this.reconnectDelay = 3000;
    this.subscriptions = new Set();
  }

  // ─────────────────────────────────────────
  //  SIGNATURE HELPER
  // ─────────────────────────────────────────
  _sign(method, path, params = {}) {
    const timestamp = Date.now().toString();
    // 把所有參數排序後拼成 query string
    const sortedKeys = Object.keys(params).sort();
    const queryStr   = sortedKeys.map(k => `${k}=${params[k]}`).join('&');

    // 待簽字串格式：METHOD\n/path\ntimestamp\nquerystring
    const toSign = [method.toUpperCase(), path, timestamp, queryStr].join('\n');

    const signature = crypto
      .createHmac('sha256', this.secretKey)
      .update(toSign)
      .digest('hex');

    return { timestamp, signature, queryStr };
  }

  // ─────────────────────────────────────────
  //  HTTP 基礎請求
  // ─────────────────────────────────────────
  async _request(method, path, params = {}) {
    const { timestamp, signature, queryStr } = this._sign(method, path, params);

    const headers = {
      'PIONEX-KEY':       this.apiKey,
      'PIONEX-SIGNATURE': signature,
      'PIONEX-TIMESTAMP': timestamp,
      'Content-Type':     'application/json',
    };

    const url = `${BASE_URL}${path}`;
    let response;

    try {
      if (method === 'GET') {
        response = await axios.get(url, { headers, params });
      } else if (method === 'POST') {
        response = await axios.post(url, params, { headers });
      } else if (method === 'DELETE') {
        response = await axios.delete(url, { headers, data: params });
      }

      if (response.data.result === false) {
        throw new Error(`Pionex API Error: ${response.data.message} (code: ${response.data.code})`);
      }

      return response.data.data ?? response.data;
    } catch (err) {
      logger.error(`[Pionex] ${method} ${path} failed: ${err.message}`);
      throw err;
    }
  }

  // ─────────────────────────────────────────
  //  ACCOUNT
  // ─────────────────────────────────────────

  /** 查詢帳戶餘額 */
  async getBalance() {
    return this._request('GET', '/api/v1/account/balances');
  }

  /** 查詢帳戶資訊 */
  async getAccountInfo() {
    return this._request('GET', '/api/v1/account/info');
  }

  // ─────────────────────────────────────────
  //  MARKET DATA
  // ─────────────────────────────────────────

  /** 取得 K 線資料 */
  async getKlines({ symbol, interval = '1h', limit = 200 }) {
    // interval: 1m 3m 5m 15m 30m 1h 2h 4h 6h 12h 1d 1w
    return this._request('GET', '/api/v1/market/klines', {
      symbol,
      interval,
      limit,
    });
  }

  /** 取得最新成交 */
  async getTicker(symbol) {
    return this._request('GET', '/api/v1/market/tickers', { symbol });
  }

  /** 取得訂單簿 */
  async getOrderBook(symbol, limit = 20) {
    return this._request('GET', '/api/v1/market/depth', { symbol, limit });
  }

  // ─────────────────────────────────────────
  //  ORDERS
  // ─────────────────────────────────────────

  /**
   * 下單
   * @param {Object} opts
   * @param {string} opts.symbol   - e.g. "BTC_USDT"
   * @param {string} opts.side     - "BUY" | "SELL"
   * @param {string} opts.type     - "LIMIT" | "MARKET" | "STOP_LIMIT"
   * @param {number} opts.size     - 下單數量（base幣）
   * @param {number} [opts.price]  - 限價單必填
   * @param {number} [opts.stopPrice] - 止損單觸發價
   * @param {string} [opts.clientOrderId] - 自訂單號
   */
  async placeOrder({ symbol, side, type, size, price, stopPrice, clientOrderId }) {
    const params = {
      symbol,
      side,
      type,
      size: size.toString(),
    };
    if (price)         params.price       = price.toString();
    if (stopPrice)     params.stopPrice   = stopPrice.toString();
    if (clientOrderId) params.clientOrderId = clientOrderId;

    logger.info(`[Order] ${side} ${size} ${symbol} @ ${price ?? 'MARKET'}`);
    return this._request('POST', '/api/v1/trade/order', params);
  }

  /** 市價買入 */
  async marketBuy(symbol, size) {
    return this.placeOrder({ symbol, side: 'BUY', type: 'MARKET', size });
  }

  /** 市價賣出 */
  async marketSell(symbol, size) {
    return this.placeOrder({ symbol, side: 'SELL', type: 'MARKET', size });
  }

  /** 限價買入 */
  async limitBuy(symbol, size, price) {
    return this.placeOrder({ symbol, side: 'BUY', type: 'LIMIT', size, price });
  }

  /** 限價賣出 */
  async limitSell(symbol, size, price) {
    return this.placeOrder({ symbol, side: 'SELL', type: 'LIMIT', size, price });
  }

  /** 取消訂單 */
  async cancelOrder(symbol, orderId) {
    return this._request('DELETE', '/api/v1/trade/order', { symbol, orderId });
  }

  /** 取消所有掛單 */
  async cancelAllOrders(symbol) {
    return this._request('DELETE', '/api/v1/trade/openOrders', { symbol });
  }

  /** 查詢單筆訂單 */
  async getOrder(symbol, orderId) {
    return this._request('GET', '/api/v1/trade/order', { symbol, orderId });
  }

  /** 查詢未成交訂單 */
  async getOpenOrders(symbol) {
    return this._request('GET', '/api/v1/trade/openOrders', { symbol });
  }

  /** 查詢歷史訂單 */
  async getOrderHistory(symbol, limit = 100) {
    return this._request('GET', '/api/v1/trade/orderHistory', { symbol, limit });
  }

  // ─────────────────────────────────────────
  //  WEBSOCKET
  // ─────────────────────────────────────────

  connectWS() {
    logger.info('[WS] 建立 WebSocket 連線...');
    this.ws = new WebSocket(WS_URL);

    this.ws.on('open', () => {
      this.wsReady = true;
      logger.info('[WS] 連線成功');
      this.emit('ws:open');
      this._startPing();

      // 重新訂閱（斷線重連後）
      this.subscriptions.forEach(sub => this._wsSend(sub));
    });

    this.ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw);
        this._handleWSMessage(msg);
      } catch (e) {
        logger.warn('[WS] 解析失敗:', raw.toString().slice(0,100));
      }
    });

    this.ws.on('close', () => {
      this.wsReady = false;
      this._stopPing();
      logger.warn('[WS] 連線斷開，3秒後重連...');
      this.emit('ws:close');
      setTimeout(() => this.connectWS(), this.reconnectDelay);
    });

    this.ws.on('error', (err) => {
      logger.error('[WS] 錯誤:', err.message);
      this.emit('ws:error', err);
    });
  }

  _wsSend(payload) {
    if (this.wsReady && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  _startPing() {
    this.pingTimer = setInterval(() => {
      this._wsSend({ op: 'ping' });
    }, 20000);
  }

  _stopPing() {
    if (this.pingTimer) { clearInterval(this.pingTimer); this.pingTimer = null; }
  }

  _handleWSMessage(msg) {
    if (msg.op === 'pong') return;

    // K 線推送
    if (msg.topic && msg.topic.includes('kline')) {
      this.emit('kline', msg.data);
    }
    // Ticker 推送
    if (msg.topic && msg.topic.includes('ticker')) {
      this.emit('ticker', msg.data);
    }
    // 訂單推送（需認證）
    if (msg.topic === 'ORDER') {
      this.emit('order', msg.data);
    }
  }

  /** 訂閱 K 線 */
  subscribeKline(symbol, interval = '15m') {
    const sub = {
      op:    'subscribe',
      topic: `kline_${interval}`,
      symbol,
    };
    this.subscriptions.add(sub);
    this._wsSend(sub);
    logger.info(`[WS] 訂閱 K線 ${symbol} ${interval}`);
  }

  /** 訂閱 Ticker */
  subscribeTicker(symbol) {
    const sub = { op: 'subscribe', topic: 'ticker', symbol };
    this.subscriptions.add(sub);
    this._wsSend(sub);
  }
}

module.exports = PionexClient;
