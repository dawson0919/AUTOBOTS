/**
 * utils/store.js
 * 輕量交易記錄存儲（JSON 檔案，可換成 SQLite/Redis）
 */

const fs   = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../logs/trades.json');

function load() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    }
  } catch (e) { /* ignore */ }
  return { trades: [], dailyPnl: {}, totalPnl: 0, balance: 0 };
}

function save(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

const db = load();

const store = {
  // 記錄一筆交易
  addTrade(trade) {
    db.trades.unshift({ ...trade, id: Date.now() });
    if (db.trades.length > 1000) db.trades = db.trades.slice(0, 1000);
    db.totalPnl += trade.pnl ?? 0;

    const day = new Date().toISOString().slice(0, 10);
    db.dailyPnl[day] = (db.dailyPnl[day] ?? 0) + (trade.pnl ?? 0);

    save(db);
  },

  getTrades(limit = 50) { return db.trades.slice(0, limit); },

  getDailyPnl(days = 30) {
    const result = [];
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      result.push({ date: key, pnl: db.dailyPnl[key] ?? 0 });
    }
    return result;
  },

  getTotalPnl() { return db.totalPnl; },

  updateBalance(b) { db.balance = b; save(db); },
  getBalance()     { return db.balance; },
};

module.exports = store;
