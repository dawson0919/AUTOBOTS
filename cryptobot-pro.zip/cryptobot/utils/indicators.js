/**
 * utils/indicators.js
 * 額外指標計算工具
 */

/** ATR（平均真實波幅） */
function calcATR(candles, period = 14) {
  if (candles.length < period + 1) return null;
  const trs = [];
  for (let i = 1; i < candles.length; i++) {
    const h = parseFloat(candles[i].high);
    const l = parseFloat(candles[i].low);
    const pc = parseFloat(candles[i - 1].close);
    trs.push(Math.max(h - l, Math.abs(h - pc), Math.abs(l - pc)));
  }
  // Wilder smoothing
  let atr = trs.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < trs.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
  }
  return +atr.toFixed(6);
}

/** 格式化數字 */
function fmt(n, dec = 2) { return (+n).toFixed(dec); }

/** 計算 PNL */
function calcPnl(side, entry, exit, qty) {
  if (side === 'BUY')  return (exit - entry) * qty;
  if (side === 'SELL') return (entry - exit) * qty;
  return 0;
}

/** 計算回報率 % */
function calcReturnPct(entry, exit, side) {
  const raw = (exit - entry) / entry * 100;
  return side === 'BUY' ? raw : -raw;
}

module.exports = { calcATR, fmt, calcPnl, calcReturnPct };
