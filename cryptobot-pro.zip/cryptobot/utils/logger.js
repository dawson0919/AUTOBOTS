/**
 * utils/logger.js
 * 簡易 Logger — 輸出到 console + 寫入 logs/bot.log
 */

const fs   = require('fs');
const path = require('path');

const logDir  = path.join(__dirname, '../logs');
const logFile = path.join(logDir, 'bot.log');

if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

function format(level, msg) {
  const ts = new Date().toISOString();
  return `[${ts}] [${level.padEnd(5)}] ${msg}`;
}

const colors = {
  INFO:  '\x1b[36m',
  WARN:  '\x1b[33m',
  ERROR: '\x1b[31m',
  DEBUG: '\x1b[90m',
  RESET: '\x1b[0m',
};

function write(level, msg) {
  const line = format(level, msg);
  // Console with color
  const col = colors[level] ?? '';
  console.log(`${col}${line}${colors.RESET}`);
  // File (no color codes)
  fs.appendFileSync(logFile, line + '\n');
}

module.exports = {
  info:  (msg) => write('INFO',  msg),
  warn:  (msg) => write('WARN',  msg),
  error: (msg) => write('ERROR', msg),
  debug: (msg) => write('DEBUG', msg),
};
