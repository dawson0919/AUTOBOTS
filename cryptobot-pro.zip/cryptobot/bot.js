/**
 * bot.js
 * 主程序 — 交易機器人入口
 * 
 * 流程：
 *  1. 載入 config
 *  2. 建立 Pionex 連線
 *  3. 訂閱 K 線 WebSocket
 *  4. 每根 K 棒收盤 → 三刀流分析
 *  5. 通過風控 → 下單
 *  6. 即時追蹤止損止盈
 *  7. 儀表板 API Server（HTTP）
 */

const http = require('http');
const path = require('path');
const fs   = require('fs');

const PionexClient     = require('./exchange/pionex');
const ThreeBladeStrategy = require('./strategy/threeBlade');
const RiskManager      = require('./risk/manager');
const logger           = require('./utils/logger');
const store            = require('./utils/store');
const { calcATR, calcPnl } = require('./utils/indicators');

// ────────────────────────────────────────────
//  CONFIG — 可改為 .env 或 config.json
// ────────────────────────────────────────────
const CONFIG = {
  apiKey:    process.env.PIONEX_API_KEY    || 'YOUR_API_KEY',
  secretKey: process.env.PIONEX_SECRET_KEY || 'YOUR_SECRET_KEY',

  symbols:   ['BTC_USDT', 'ETH_USDT', 'SOL_USDT'],
  interval:  '15m',      // K 線週期
  dryRun:    true,       // true = 模擬，false = 實盤

  risk: {
    maxRiskPerTrade:   0.02,   // 每筆最大虧損 2%
    maxDailyLoss:      0.05,   // 每日熔斷 5%
    maxOpenPositions:  5,
    minSignalStrength: 3,      // 要求三刀全中
  },

  strategy: {
    rsiOversold:  35,
    rsiOverbought:65,
    emaFast:      9,
    emaSlow:      21,
  },

  dashboard: {
    port: 3000,
  },
};

// ────────────────────────────────────────────
//  INIT MODULES
// ────────────────────────────────────────────
const client   = new PionexClient({ apiKey: CONFIG.apiKey, secretKey: CONFIG.secretKey });
const strategy = new ThreeBladeStrategy(CONFIG.strategy);
const risk     = new RiskManager(CONFIG.risk);

// K 棒緩存
const candleCache = {};  // { 'BTC_USDT': [{...}, ...] }

// ────────────────────────────────────────────
//  MAIN LOOP
// ────────────────────────────────────────────
async function main() {
  logger.info('='.repeat(50));
  logger.info('  CryptoBot Pro 啟動');
  logger.info(`  模式: ${CONFIG.dryRun ? '📋 模擬交易 (DRY RUN)' : '🔴 實盤交易'}`);
  logger.info(`  交易對: ${CONFIG.symbols.join(', ')}`);
  logger.info('='.repeat(50));

  // 1. 獲取初始帳戶餘額
  let balance = 0;
  if (!CONFIG.dryRun) {
    try {
      const acct = await client.getBalance();
      balance = parseFloat(acct.find(a => a.coin === 'USDT')?.free ?? '0');
    } catch (e) {
      logger.warn('[Init] 無法獲取帳戶餘額，使用模擬餘額 $10,000');
      balance = 10000;
    }
  } else {
    balance = 10000;
    logger.info(`[DryRun] 模擬資金: $${balance}`);
  }

  risk.init(balance);
  store.updateBalance(balance);

  // 2. 預載 K 線歷史
  for (const sym of CONFIG.symbols) {
    try {
      const klines = await fetchKlines(sym);
      candleCache[sym] = klines;
      logger.info(`[Init] ${sym} 已載入 ${klines.length} 根 K 棒`);
    } catch (e) {
      candleCache[sym] = generateMockCandles(200);  // Fallback 模擬資料
      logger.warn(`[Init] ${sym} 使用模擬 K 棒`);
    }
    await sleep(300);  // 避免頻率限制
  }

  // 3. 連接 WebSocket
  client.connectWS();

  client.on('ws:open', () => {
    CONFIG.symbols.forEach(sym => {
      client.subscribeKline(sym, CONFIG.interval);
      client.subscribeTicker(sym);
    });
  });

  // 4. 收到新 K 棒 → 策略分析
  client.on('kline', async (data) => {
    const { symbol, kline } = data;
    if (!kline.confirm) return;   // 未收盤的 K 棒忽略

    // 更新緩存
    if (!candleCache[symbol]) candleCache[symbol] = [];
    candleCache[symbol].push(kline);
    if (candleCache[symbol].length > 300) candleCache[symbol].shift();

    await analyzeAndTrade(symbol, candleCache[symbol], balance);
  });

  // 5. Ticker 更新 → 止損止盈檢查
  const latestPrices = {};
  client.on('ticker', (data) => {
    latestPrices[data.symbol] = parseFloat(data.close);
    checkStopLossTakeProfit(latestPrices, balance);
  });

  // 6. 風控事件
  risk.on('halt', (reason) => {
    logger.error(`[Bot] 熔斷觸發！停止交易: ${reason}`);
  });

  // 7. 啟動 WebSocket 模擬（DryRun 下自動生成 K 棒）
  if (CONFIG.dryRun) {
    startDryRunSimulation(balance);
  }

  // 8. 啟動 Dashboard HTTP Server
  startDashboardServer();

  logger.info('[Bot] 機器人就緒，等待信號...');
}

// ────────────────────────────────────────────
//  分析 + 交易
// ────────────────────────────────────────────
async function analyzeAndTrade(symbol, candles, balance) {
  const signal = strategy.analyze(candles);

  if (signal.signal === 'NONE') return;

  logger.info(`[Signal] ${symbol} → ${signal.signal} | RSI:${signal.indicators.rsi} | Hist:${signal.indicators.macdHist}`);

  // 只交易強信號
  if (!signal.signal.includes('STRONG')) return;

  const side   = signal.signal.includes('LONG') ? 'BUY' : 'SELL';
  const atr    = calcATR(candles) ?? signal.price * 0.01;
  const slMult = side === 'BUY' ? 1.5 : 1.5;
  const tpMult = 2.5;

  const sltp = strategy.calcSLTP(signal.price, signal.signal, atr, slMult, tpMult);

  // 風控過濾
  const check = risk.checkEntry({ symbol, signal, balance });
  if (!check.allowed) {
    logger.info(`[Risk] ${symbol} 拒絕進場: ${check.reason}`);
    return;
  }

  // 計算倉位
  const sizing = risk.calcPositionSize({
    balance,
    entryPrice:    signal.price,
    stopLossPrice: sltp.stopLoss,
  });

  logger.info(`[Trade] 準備 ${side} ${symbol} qty=${sizing.qty} SL=${sltp.stopLoss} TP=${sltp.takeProfit}`);

  if (CONFIG.dryRun) {
    // 模擬下單
    const mockOrderId = `MOCK_${Date.now()}`;
    risk.recordOpen({
      symbol, side,
      entryPrice: signal.price,
      qty:        sizing.qty,
      stopLoss:   sltp.stopLoss,
      takeProfit: sltp.takeProfit,
      orderId:    mockOrderId,
    });
    logger.info(`[DryRun] 模擬訂單成立 ${mockOrderId}`);
  } else {
    try {
      const order = side === 'BUY'
        ? await client.marketBuy(symbol, sizing.qty)
        : await client.marketSell(symbol, sizing.qty);

      risk.recordOpen({
        symbol, side,
        entryPrice: signal.price,
        qty:        sizing.qty,
        stopLoss:   sltp.stopLoss,
        takeProfit: sltp.takeProfit,
        orderId:    order.orderId,
      });

      logger.info(`[Order] ✅ 成立 orderId=${order.orderId}`);
    } catch (e) {
      logger.error(`[Order] ❌ 下單失敗: ${e.message}`);
    }
  }
}

// ────────────────────────────────────────────
//  止損止盈監控
// ────────────────────────────────────────────
async function checkStopLossTakeProfit(prices, balance) {
  const triggered = risk.checkPositions(prices);

  for (const { symbol, reason, price, pos } of triggered) {
    const pnl = calcPnl(pos.side, pos.entryPrice, price, pos.qty);
    logger.info(`[${reason}] ${symbol} 觸發 @ ${price} | PNL: ${pnl > 0 ? '+' : ''}${pnl.toFixed(2)}`);

    if (!CONFIG.dryRun) {
      try {
        const closeSide = pos.side === 'BUY' ? 'SELL' : 'BUY';
        await client.marketSell(symbol, pos.qty);
      } catch (e) {
        logger.error(`[Close] 平倉失敗: ${e.message}`);
      }
    }

    risk.recordClose({ symbol, exitPrice: price, pnl });
    store.addTrade({
      symbol, side: pos.side, reason,
      entryPrice: pos.entryPrice, exitPrice: price,
      qty: pos.qty, pnl,
      openTime:  pos.openTime,
      closeTime: Date.now(),
    });
  }
}

// ────────────────────────────────────────────
//  Dashboard HTTP API Server
// ────────────────────────────────────────────
function startDashboardServer() {
  const server = http.createServer((req, res) => {
    const url = req.url;

    // CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Content-Type', 'application/json');

    if (url === '/api/stats') {
      const stats  = risk.getStats();
      const trades = store.getTrades(10);
      const daily  = store.getDailyPnl(30);
      res.end(JSON.stringify({
        balance:       store.getBalance(),
        totalPnl:      store.getTotalPnl(),
        openPositions: risk.getOpenPositions(),
        ...stats,
        recentTrades: trades,
        dailyPnl:     daily,
      }));

    } else if (url === '/api/positions') {
      res.end(JSON.stringify(risk.getOpenPositions()));

    } else if (url === '/api/trades') {
      res.end(JSON.stringify(store.getTrades(100)));

    } else if (url === '/api/health') {
      res.end(JSON.stringify({ status: 'ok', uptime: process.uptime(), halted: risk.state.halted }));

    } else if (url === '/' || url === '/dashboard') {
      // 提供 HTML 儀表板
      res.setHeader('Content-Type', 'text/html');
      const htmlPath = path.join(__dirname, 'dashboard/index.html');
      if (fs.existsSync(htmlPath)) {
        res.end(fs.readFileSync(htmlPath));
      } else {
        res.end('<h1>Dashboard not found</h1>');
      }
    } else {
      res.writeHead(404);
      res.end(JSON.stringify({ error: 'Not found' }));
    }
  });

  server.listen(CONFIG.dashboard.port, () => {
    logger.info(`[Dashboard] 儀表板啟動: http://localhost:${CONFIG.dashboard.port}`);
    logger.info(`[Dashboard] API: http://localhost:${CONFIG.dashboard.port}/api/stats`);
  });
}

// ────────────────────────────────────────────
//  DRY RUN 模擬
// ────────────────────────────────────────────
function startDryRunSimulation(balance) {
  let tick = 0;
  setInterval(async () => {
    tick++;
    for (const sym of CONFIG.symbols) {
      if (!candleCache[sym]) continue;
      const newCandle = generateNextCandle(candleCache[sym].at(-1));
      candleCache[sym].push({ ...newCandle, confirm: true });
      if (candleCache[sym].length > 300) candleCache[sym].shift();

      if (tick % 4 === 0) {  // 每 4 tick 觸發一次分析（模擬 K 棒收盤）
        await analyzeAndTrade(sym, candleCache[sym], balance);
      }
    }
  }, 5000);  // 每 5 秒生成一根模擬 K 棒
}

// ────────────────────────────────────────────
//  工具函數
// ────────────────────────────────────────────
async function fetchKlines(symbol) {
  try {
    const data = await client.getKlines({ symbol, interval: CONFIG.interval, limit: 200 });
    return data.klines ?? data;
  } catch (e) {
    return generateMockCandles(200);
  }
}

function generateMockCandles(n) {
  let price = 67000;
  return Array.from({ length: n }, (_, i) => {
    const change = (Math.random() - 0.48) * 200;
    price = Math.max(price + change, 100);
    const h = price + Math.random() * 150;
    const l = price - Math.random() * 150;
    return {
      open: price - change, high: h, low: l, close: price,
      volume: Math.random() * 100 + 10,
      timestamp: Date.now() - (n - i) * 15 * 60 * 1000,
      confirm: true,
    };
  });
}

function generateNextCandle(prev) {
  const change = (Math.random() - 0.48) * 200;
  const close  = Math.max(parseFloat(prev.close) + change, 100);
  return {
    open:   parseFloat(prev.close),
    high:   close + Math.random() * 150,
    low:    close - Math.random() * 150,
    close,
    volume: Math.random() * 100 + 10,
    timestamp: Date.now(),
  };
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ────────────────────────────────────────────
//  PROCESS HANDLER
// ────────────────────────────────────────────
process.on('uncaughtException',  e => logger.error(`未捕獲錯誤: ${e.message}`));
process.on('unhandledRejection', e => logger.error(`未處理 Promise: ${e}`));
process.on('SIGINT', () => {
  logger.info('[Bot] 收到 SIGINT，安全關閉...');
  // 可在此平倉所有部位
  process.exit(0);
});

// ────────────────────────────────────────────
//  START
// ────────────────────────────────────────────
main().catch(e => logger.error(`[Main] 啟動失敗: ${e.message}`));
