/**
 * strategy/threeBlade.js
 * 三刀流策略 — RSI + EMA 交叉 + MACD 三重確認
 *
 * 做多條件（三刀同向）：
 *   刀1：RSI(14) < 35（超賣區域反彈）
 *   刀2：EMA(9) 由下往上穿越 EMA(21)（短期動能轉強）
 *   刀3：MACD histogram 由負轉正（動量確認）
 *
 * 做空條件（三刀反向）：
 *   刀1：RSI(14) > 65（超買區域回落）
 *   刀2：EMA(9) 由上往下穿越 EMA(21)
 *   刀3：MACD histogram 由正轉負
 */

const { EMA, RSI, MACD } = require('technicalindicators');

class ThreeBladeStrategy {
  constructor(config = {}) {
    this.name = 'ThreeBlade';
    this.config = {
      // RSI
      rsiPeriod:    config.rsiPeriod    ?? 14,
      rsiOversold:  config.rsiOversold  ?? 35,
      rsiOverbought:config.rsiOverbought?? 65,
      // EMA
      emaFast:      config.emaFast      ?? 9,
      emaSlow:      config.emaSlow      ?? 21,
      // MACD
      macdFast:     config.macdFast     ?? 12,
      macdSlow:     config.macdSlow     ?? 26,
      macdSignal:   config.macdSignal   ?? 9,
      // 最少需要幾根 K 棒
      minCandles:   config.minCandles   ?? 50,
    };
  }

  /**
   * 分析 K 線，回傳信號
   * @param {Array} candles - [{open,high,low,close,volume,timestamp}, ...]
   * @returns {Object} signal
   */
  analyze(candles) {
    const n = candles.length;

    if (n < this.config.minCandles) {
      return { signal: 'NONE', reason: `K棒不足 (${n}/${this.config.minCandles})` };
    }

    const closes = candles.map(c => parseFloat(c.close));

    // ── 計算指標 ──────────────────────────────────
    const rsiArr = RSI.calculate({
      period: this.config.rsiPeriod,
      values: closes,
    });

    const emaFastArr = EMA.calculate({
      period: this.config.emaFast,
      values: closes,
    });

    const emaSlowArr = EMA.calculate({
      period: this.config.emaSlow,
      values: closes,
    });

    const macdResult = MACD.calculate({
      fastPeriod:       this.config.macdFast,
      slowPeriod:       this.config.macdSlow,
      signalPeriod:     this.config.macdSignal,
      values:           closes,
      SimpleMAOscillator: false,
      SimpleMASignal:   false,
    });

    // ── 取最新兩根值（用來判斷交叉/轉向）────────────
    const rsi      = rsiArr.at(-1);
    const rsiPrev  = rsiArr.at(-2);

    const emaF     = emaFastArr.at(-1);
    const emaFPrev = emaFastArr.at(-2);
    const emaS     = emaSlowArr.at(-1);
    const emaSSlow = emaSlowArr.at(-2);   // 對齊 emaFPrev

    const macd     = macdResult.at(-1);
    const macdPrev = macdResult.at(-2);

    if (!macd || !macdPrev) return { signal: 'NONE', reason: 'MACD 資料不足' };

    // ── 三刀判斷 ──────────────────────────────────
    // 做多三刀
    const blade1Long = rsi < this.config.rsiOversold && rsi > rsiPrev;          // RSI 超賣 + 反彈
    const blade2Long = emaFPrev <= emaSSlow && emaF > emaS;                      // EMA 黃金交叉
    const blade3Long = macdPrev.histogram < 0 && macd.histogram > 0;             // MACD hist 轉正

    // 做空三刀
    const blade1Short = rsi > this.config.rsiOverbought && rsi < rsiPrev;        // RSI 超買 + 回落
    const blade2Short = emaFPrev >= emaSSlow && emaF < emaS;                     // EMA 死亡交叉
    const blade3Short = macdPrev.histogram > 0 && macd.histogram < 0;            // MACD hist 轉負

    const longScore  = [blade1Long,  blade2Long,  blade3Long].filter(Boolean).length;
    const shortScore = [blade1Short, blade2Short, blade3Short].filter(Boolean).length;

    // 三刀全中才入場；兩刀也可考慮（弱信號）
    const signal = this._determineSignal(longScore, shortScore);

    return {
      signal,
      strength: Math.max(longScore, shortScore),      // 1~3
      indicators: {
        rsi:       +rsi.toFixed(2),
        emaFast:   +emaF.toFixed(4),
        emaSlow:   +emaS.toFixed(4),
        macdLine:  +macd.MACD.toFixed(4),
        macdSignal:+macd.signal.toFixed(4),
        macdHist:  +macd.histogram.toFixed(4),
      },
      blades: {
        long:  { blade1: blade1Long,  blade2: blade2Long,  blade3: blade3Long  },
        short: { blade1: blade1Short, blade2: blade2Short, blade3: blade3Short },
      },
      timestamp: Date.now(),
      price: closes.at(-1),
    };
  }

  _determineSignal(longScore, shortScore) {
    if (longScore === 3)  return 'LONG_STRONG';   // 三刀全中
    if (shortScore === 3) return 'SHORT_STRONG';
    if (longScore === 2)  return 'LONG_WEAK';     // 兩刀（可選擇不交易）
    if (shortScore === 2) return 'SHORT_WEAK';
    return 'NONE';
  }

  /** 計算建議止盈止損 */
  calcSLTP(entryPrice, signal, atr, slMult = 1.5, tpMult = 2.5) {
    const isLong = signal.includes('LONG');
    const sl = isLong
      ? entryPrice - atr * slMult
      : entryPrice + atr * slMult;
    const tp = isLong
      ? entryPrice + atr * tpMult
      : entryPrice - atr * tpMult;
    return {
      stopLoss:   +sl.toFixed(4),
      takeProfit: +tp.toFixed(4),
      riskReward: +(tpMult / slMult).toFixed(2),
    };
  }
}

module.exports = ThreeBladeStrategy;
